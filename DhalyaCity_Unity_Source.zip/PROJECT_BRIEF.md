# DhalyaCity — Brief para colaboração

## Objetivo atual

Criar a primeira versão jogável de um jogo 3D estilizado de sobrevivência, exploração, construção e reconstrução de um bairro pós-apocalíptico futurista.

## O que já existe

- Cena `Assets/DhalyaCity/Scenes/Codo_BairroInicial.unity`
- Personagem em terceira pessoa, câmera, corrida e pulo
- Casa inicial explorável e objetos interativos
- Coleta de Madeira, Pedra e Sucata
- Inventário e HUD simples
- Baú de armazenamento construível
- Salvamento básico no slot 1
- Estrutura de clima e áreas reservadas para agricultura, água e expansão

## Organização importante

Os sistemas estão separados em `Assets/DhalyaCity/Scripts/Runtime` por responsabilidade: Player, Interaction, Inventory, Building, Environment, UI e Save.

## Próxima melhoria recomendada

Melhorar a apresentação visual e a usabilidade do protótipo sem remover os sistemas atuais. Priorizar materiais estilizados, iluminação, uma interface mais polida e uma casa inicial com leitura espacial mais clara. Não criar cidade inteira, combate, multiplayer ou sistemas completos de agricultura nesta etapa.
