# DhalyaCity — Bairro Inicial

Este é o primeiro protótipo jogável de DhalyaCity: um bairro pós-apocalíptico futurista para explorar, coletar recursos e começar a reconstrução.

## Abrir e jogar

Abra esta pasta no Unity 6 (ou Unity 2022 LTS), depois abra a cena `Assets/DhalyaCity/Scenes/Codo_BairroInicial.unity` e pressione Play.

## Controles

- `WASD`: andar
- `Shift`: correr
- `Espaço`: pular
- `Mouse`: olhar e mover a câmera
- `E`: interagir ou coletar
- `B`: abrir/fechar o modo de construir baú
- Clique esquerdo: colocar o baú na área permitida
- `F5`: salvar no slot 1
- `F9`: carregar o slot 1

O primeiro baú custa 5 Madeira e 3 Sucata. Ao abrir um armário, caixa ou baú, use os botões da janela para guardar recursos.

## Sistemas prontos

- Personagem em terceira pessoa, corrida, pulo e câmera com colisão
- Casa inicial explorável com porta, móveis, armário, caixa e bancada
- Recursos de Madeira, Pedra e Sucata
- Inventário e interface de jogo
- Interações por proximidade
- Construção modular do baú de armazenamento
- Clima ensolarado, preparado para novos tipos de clima
- Salvamento da posição, inventário, recursos coletados, porta e baús

## Organização dos scripts

Os sistemas ficam separados em `Assets/DhalyaCity/Scripts/Runtime`:

- `Player`: personagem e câmera
- `Interaction`: portas, objetos e coleta
- `Inventory`: recursos do jogador
- `Building`: construção e baús
- `Environment`: clima
- `UI`: interface
- `Save`: persistência do jogo

O gerador do mapa fica em `Scripts/Editor/DhalyaCityMapGenerator.cs`. Para recriar toda a cena, use o menu `DhalyaCity > Gerar Mapa Inicial de Codo`.
