#if UNITY_EDITOR
using UnityEditor;
using UnityEditor.SceneManagement;

public static class DhalyaCityStartup
{
    const string ScenePath = "Assets/DhalyaCity/Scenes/Codo_BairroInicial.unity";

    [InitializeOnLoadMethod]
    static void ConfigurePlayModeScene()
    {
        EditorApplication.delayCall += () =>
        {
            SceneAsset scene = AssetDatabase.LoadAssetAtPath<SceneAsset>(ScenePath);
            if (scene != null) EditorSceneManager.playModeStartScene = scene;
        };
    }

    [MenuItem("DhalyaCity/Abrir Bairro Inicial")]
    static void OpenStartingDistrict()
    {
        EditorSceneManager.OpenScene(ScenePath);
    }
}
#endif
