#if UNITY_EDITOR
using UnityEditor;
using UnityEditor.SceneManagement;
using UnityEngine;
using UnityEngine.SceneManagement;
using DhalyaCity;

public static class DhalyaCityMapGenerator
{
    static Transform root;
    static Material groundMat, roadMat, sidewalkMat, wallMat, roofMat, woodMat, metalMat, greenMat, dryGreenMat, blueGlowMat, waterReserveMat;

    [MenuItem("DhalyaCity/Gerar Mapa Inicial de Codo")]
    public static void Generate()
    {
        Scene scene = EditorSceneManager.NewScene(NewSceneSetup.EmptyScene, NewSceneMode.Single);

        const string sceneDirectory = "Assets/DhalyaCity/Scenes";
        if (!AssetDatabase.IsValidFolder(sceneDirectory))
            System.IO.Directory.CreateDirectory(sceneDirectory);

        GameObject rootGO = new GameObject("DhalyaCity_Codo_BairroInicial");
        root = rootGO.transform;

        CreateMaterials();
        CreateLighting();
        CreateGround();
        CreateRoadNetwork();
        CreateStartingHouse();
        CreateResidentialBlocks();
        CreatePlaza();
        CreateWorkshop();
        CreateStore();
        CreateFutureZones();
        CreateResources();
        CreateVegetation();
        CreateStreetProps();
        CreateFutureTech();
        CreatePlayer();
        CreateGameSystems();

        Selection.activeGameObject = rootGO;

        string scenePath = sceneDirectory + "/Codo_BairroInicial.unity";
        EditorSceneManager.SaveScene(scene, scenePath);
        EditorBuildSettings.scenes = new[] { new EditorBuildSettingsScene(scenePath, true) };
        EditorSceneManager.playModeStartScene = AssetDatabase.LoadAssetAtPath<SceneAsset>(scenePath);

        Debug.Log("DhalyaCity: Bairro Inicial de Codo gerado e salvo em " + scenePath);
    }

    static Material Mat(string name, Color color, float metallic = 0f, float smooth = 0.25f)
    {
        Material m = new Material(Shader.Find("Standard"));
        m.name = name;
        m.color = color;
        m.SetFloat("_Metallic", metallic);
        m.SetFloat("_Glossiness", smooth);
        return m;
    }

    static void CreateMaterials()
    {
        groundMat = Mat("MAT_TerraGrama", new Color(0.28f,0.35f,0.20f), 0, .15f);
        roadMat = Mat("MAT_Asfalto", new Color(0.12f,0.13f,0.14f), 0, .1f);
        sidewalkMat = Mat("MAT_Calcada", new Color(0.42f,0.42f,0.40f), 0, .2f);
        wallMat = Mat("MAT_Paredes", new Color(0.62f,0.58f,0.50f), 0, .15f);
        roofMat = Mat("MAT_Telhado", new Color(0.27f,0.16f,0.12f), 0, .15f);
        woodMat = Mat("MAT_Madeira", new Color(0.35f,0.19f,0.08f), 0, .1f);
        metalMat = Mat("MAT_Metal", new Color(0.25f,0.28f,0.30f), .55f, .25f);
        greenMat = Mat("MAT_Vegetacao", new Color(0.18f,0.42f,0.18f), 0, .1f);
        dryGreenMat = Mat("MAT_VegetacaoSeca", new Color(0.40f,0.45f,0.18f), 0, .1f);
        blueGlowMat = Mat("MAT_TechGlow", new Color(0.05f,0.65f,0.85f), .15f, .55f);
        blueGlowMat.EnableKeyword("_EMISSION");
        blueGlowMat.SetColor("_EmissionColor", new Color(0.0f,0.5f,0.8f) * 1.6f);
        waterReserveMat = Mat("MAT_AguaReserva", new Color(0.05f,0.22f,0.30f), .1f, .65f);
    }

    static GameObject Cube(string name, Vector3 pos, Vector3 scale, Material mat, Transform parent = null)
    {
        GameObject g = GameObject.CreatePrimitive(PrimitiveType.Cube);
        g.name = name;
        g.transform.position = pos;
        g.transform.localScale = scale;
        g.transform.SetParent(parent ? parent : root);
        if (mat) g.GetComponent<Renderer>().sharedMaterial = mat;
        return g;
    }

    static GameObject Cylinder(string name, Vector3 pos, Vector3 scale, Material mat, Transform parent = null)
    {
        GameObject g = GameObject.CreatePrimitive(PrimitiveType.Cylinder);
        g.name = name;
        g.transform.position = pos;
        g.transform.localScale = scale;
        g.transform.SetParent(parent ? parent : root);
        if (mat) g.GetComponent<Renderer>().sharedMaterial = mat;
        return g;
    }

    static GameObject Sphere(string name, Vector3 pos, Vector3 scale, Material mat, Transform parent = null)
    {
        GameObject g = GameObject.CreatePrimitive(PrimitiveType.Sphere);
        g.name = name;
        g.transform.position = pos;
        g.transform.localScale = scale;
        g.transform.SetParent(parent ? parent : root);
        if (mat) g.GetComponent<Renderer>().sharedMaterial = mat;
        return g;
    }

    static void CreateLighting()
    {
        GameObject sun = new GameObject("Sun");
        sun.transform.SetParent(root);
        Light l = sun.AddComponent<Light>();
        l.type = LightType.Directional;
        l.intensity = 1.15f;
        l.color = new Color(1f,0.93f,0.82f);
        sun.transform.rotation = Quaternion.Euler(45f, -35f, 0f);

        RenderSettings.ambientLight = new Color(0.42f,0.45f,0.48f);
    }

    static void CreateGround()
    {
        Cube("Terreno_Base", new Vector3(0,-0.6f,0), new Vector3(260,1,260), groundMat);

        // gently raised lots / visual terrain breaks
        Cube("Lote_Noroeste", new Vector3(-82,-0.05f,72), new Vector3(55,.25f,55), groundMat);
        Cube("Lote_Nordeste", new Vector3(82,-0.05f,72), new Vector3(55,.25f,55), groundMat);
        Cube("Lote_Sul", new Vector3(0,-0.05f,-82), new Vector3(75,.25f,48), groundMat);
    }

    static void CreateRoadNetwork()
    {
        // Main avenue
        Cube("Rua_Principal", new Vector3(0,0,0), new Vector3(18,.15f,240), roadMat);
        // Cross roads
        Cube("Rua_LesteOeste_Norte", new Vector3(0,0,58), new Vector3(210,.15f,14), roadMat);
        Cube("Rua_LesteOeste_Sul", new Vector3(0,0,-55), new Vector3(210,.15f,14), roadMat);

        // Sidewalks
        float[] xs = {-12f, 12f};
        foreach(float x in xs)
            Cube("Calcada_Principal", new Vector3(x,.08f,0), new Vector3(5,.18f,240), sidewalkMat);

        float[] zs = {68f,48f,-45f,-65f};
        foreach(float z in zs)
            Cube("Calcada_Transversal", new Vector3(0,.08f,z), new Vector3(210,.18f,5), sidewalkMat);

        // Road markings
        for(int z=-110; z<=110; z+=18)
            Cube("Faixa_Central", new Vector3(0,.10f,z), new Vector3(.35f,.05f,7f), sidewalkMat);
    }

    static void CreateHouse(string name, Vector3 pos, float rot, bool abandoned = true)
    {
        GameObject h = new GameObject(name);
        h.transform.SetParent(root);
        h.transform.position = pos;
        h.transform.rotation = Quaternion.Euler(0,rot,0);

        Cube("Base", pos + new Vector3(0,1.5f,0), new Vector3(10,3,8), wallMat, h.transform);
        GameObject roof = Cube("Telhado", pos + new Vector3(0,3.7f,0), new Vector3(10.8f,.8f,8.8f), roofMat, h.transform);
        Cube("Porta", pos + new Vector3(0,1.4f,-4.1f), new Vector3(1.5f,2.6f,.25f), woodMat, h.transform);
        Cube("Janela_E", pos + new Vector3(-2.8f,1.8f,-4.15f), new Vector3(1.8f,1.4f,.18f), blueGlowMat, h.transform);
        Cube("Janela_D", pos + new Vector3(2.8f,1.8f,-4.15f), new Vector3(1.8f,1.4f,.18f), blueGlowMat, h.transform);

        if(abandoned)
        {
            Cube("Entulho", pos + new Vector3(4.7f,.35f,3.2f), new Vector3(2,.7f,1.2f), metalMat, h.transform);
        }
    }

    static void CreateStartingHouse()
    {
        Vector3 p = new Vector3(-35, 0, -88);
        GameObject house = new GameObject("CASA_INICIAL_JOGADOR");
        house.transform.SetParent(root);
        Cube("Piso", p + new Vector3(0,.08f,0), new Vector3(14,.16f,10), sidewalkMat, house.transform);
        Cube("Parede_Fundo", p + new Vector3(0,2.2f,5), new Vector3(14,.35f,4.5f), wallMat, house.transform);
        Cube("Parede_Esquerda", p + new Vector3(-7,2.2f,0), new Vector3(.35f,4.5f,10), wallMat, house.transform);
        Cube("Parede_Direita", p + new Vector3(7,2.2f,0), new Vector3(.35f,4.5f,10), wallMat, house.transform);
        Cube("Frente_E", p + new Vector3(-4.6f,2.2f,-5), new Vector3(4.8f,4.5f,.35f), wallMat, house.transform);
        Cube("Frente_D", p + new Vector3(4.6f,2.2f,-5), new Vector3(4.8f,4.5f,.35f), wallMat, house.transform);
        Cube("Teto", p + new Vector3(0,4.7f,0), new Vector3(14.6f,.35f,10.6f), roofMat, house.transform);
        Cube("Divisoria_Quarto", p + new Vector3(1.4f,1.7f,1), new Vector3(.25f,3.4f,7), wallMat, house.transform);
        Cube("Divisoria_Cozinha", p + new Vector3(-2.8f,1.7f,-.8f), new Vector3(5,.25f,3.5f), wallMat, house.transform);
        Cube("Sofa_Abandonado", p + new Vector3(-3,.6f,2.8f), new Vector3(2.8f,1.1f,1.1f), metalMat, house.transform);
        Cube("Cama", p + new Vector3(4.2f,.55f,2.5f), new Vector3(3.4f,.75f,2.2f), woodMat, house.transform);
        GameObject cabinet = Cube("Armario_Interativo", p + new Vector3(5.5f,1.2f,-2.6f), new Vector3(1.3f,2.4f,.7f), woodMat, house.transform);
        cabinet.AddComponent<ContainerInteractable>().prompt = "Pressione E para abrir o armário";
        GameObject bench = Cube("Bancada_Interativa", p + new Vector3(-4.2f,.85f,-2.7f), new Vector3(3.2f,1.7f,.9f), metalMat, house.transform);
        bench.AddComponent<FutureStationInteractable>().prompt = "Pressione E para usar a bancada";
        GameObject box = Cube("Caixa_Interativa", p + new Vector3(-2.3f,.45f,3.6f), new Vector3(1.1f,.9f,1.1f), woodMat, house.transform);
        box.AddComponent<ContainerInteractable>().prompt = "Pressione E para abrir a caixa";
        GameObject door = new GameObject("Porta_Casa_Inicial");
        door.transform.SetParent(house.transform);
        door.transform.position = p + new Vector3(-1.1f, 0, -5.05f);
        Cube("Folha", p + new Vector3(-.1f,2f,-5.05f), new Vector3(2,4,.22f), woodMat, door.transform);
        DoorInteractable doorInteraction = door.AddComponent<DoorInteractable>();
        doorInteraction.saveId = "porta_casa_inicial";
        Cube("Area_Quintal_Inicial", new Vector3(-48,.02f,-88), new Vector3(16,.08f,18), groundMat);

        GameObject zone = Cube("ZONA_CONSTRUCAO_INICIAL", new Vector3(-49,.09f,-88), new Vector3(13,.12f,15), sidewalkMat);
        zone.AddComponent<DhalyaBuildZone>().zoneName = "Quintal da Casa Inicial";
    }

    static void CreateResidentialBlocks()
    {
        Vector3[] positions = {
            new Vector3(-42,0,88), new Vector3(-72,0,88), new Vector3(-98,0,88),
            new Vector3(42,0,88), new Vector3(72,0,88), new Vector3(98,0,88),
            new Vector3(-42,0,24), new Vector3(-78,0,24),
            new Vector3(42,0,24), new Vector3(78,0,24),
            new Vector3(-78,0,-88), new Vector3(78,0,-88)
        };

        for(int i=0;i<positions.Length;i++)
        {
            float rot = positions[i].x < 0 ? 90f : -90f;
            if (Mathf.Abs(positions[i].z) > 70) rot = positions[i].z > 0 ? 180f : 0f;
            CreateHouse("Casa_Abandonada_" + (i+1).ToString("00"), positions[i], rot);
        }
    }

    static void CreatePlaza()
    {
        GameObject plaza = new GameObject("Praca_Central");
        plaza.transform.SetParent(root);

        Cube("Piso_Praca", new Vector3(-58,.03f,-8), new Vector3(42,.12f,34), sidewalkMat, plaza.transform);
        Cylinder("Fonte_Seca", new Vector3(-58,.5f,-8), new Vector3(4,.5f,4), metalMat, plaza.transform);

        for(int i=0;i<4;i++)
        {
            float a = i * 90f * Mathf.Deg2Rad;
            Vector3 p = new Vector3(-58 + Mathf.Cos(a)*12f, 1.2f, -8 + Mathf.Sin(a)*9f);
            CreateTree(p, plaza.transform);
        }

        Cube("Banco_01", new Vector3(-68,.7f,-8), new Vector3(4,.5f,1), woodMat, plaza.transform);
        Cube("Banco_02", new Vector3(-48,.7f,-8), new Vector3(4,.5f,1), woodMat, plaza.transform);
    }

    static void CreateWorkshop()
    {
        GameObject g = new GameObject("Oficina_Abandonada");
        g.transform.SetParent(root);
        Vector3 p = new Vector3(55,0,-18);
        Cube("Predio", p + Vector3.up*2.5f, new Vector3(18,5,14), metalMat, g.transform);
        Cube("Portao", p + new Vector3(0,2.1f,-7.1f), new Vector3(8,4,.25f), roadMat, g.transform);
        Cube("Placa", p + new Vector3(0,5.4f,-7.2f), new Vector3(7,1.2f,.2f), blueGlowMat, g.transform);
    }

    static void CreateStore()
    {
        GameObject g = new GameObject("Mercadinho_Abandonado");
        g.transform.SetParent(root);
        Vector3 p = new Vector3(65,0,18);
        Cube("Predio", p + Vector3.up*2.2f, new Vector3(16,4.4f,12), wallMat, g.transform);
        Cube("Fachada", p + new Vector3(0,2.3f,-6.1f), new Vector3(9,2,.2f), metalMat, g.transform);
    }

    static void CreateFutureZones()
    {
        GameObject farm = Cube("RESERVA_FUTURA_CANTEIROS", new Vector3(-95,.03f,-30), new Vector3(34,.08f,28), groundMat);
        farm.AddComponent<DhalyaFutureExpansion>().futureUse = "Agricultura / Canteiros / Sementes";

        GameObject lake = Cylinder("RESERVA_FUTURA_LAGO", new Vector3(95,-.25f,-82), new Vector3(13,.15f,10), waterReserveMat);
        lake.AddComponent<DhalyaFutureExpansion>().futureUse = "Lago / Peixes / Pesca / Água";

        GameObject water = Cube("RESERVA_FUTURA_AGUA", new Vector3(100,.03f,86), new Vector3(26,.08f,24), groundMat);
        water.AddComponent<DhalyaFutureExpansion>().futureUse = "Captação de Chuva / Reservatórios / Tratamento";

        GameObject energy = Cube("RESERVA_FUTURA_ENERGIA", new Vector3(100,.03f,45), new Vector3(24,.08f,20), groundMat);
        energy.AddComponent<DhalyaFutureExpansion>().futureUse = "Geradores / Solar / Baterias";

        // Future road exits
        Cube("Saida_Futura_Norte", new Vector3(0,0,126), new Vector3(18,.15f,12), roadMat)
            .AddComponent<DhalyaFutureExpansion>().futureUse = "Expansão Bairro Norte";
        Cube("Saida_Futura_Sul", new Vector3(0,0,-126), new Vector3(18,.15f,12), roadMat)
            .AddComponent<DhalyaFutureExpansion>().futureUse = "Expansão Bairro Sul";
    }

    static void CreateResources()
    {
        for(int i=0;i<10;i++)
        {
            Vector3 p = new Vector3(-105 + (i%5)*10, .6f, 35 + (i/5)*10);
            GameObject wood = Cube("Recurso_Madeira", p, new Vector3(2.5f,.8f,.8f), woodMat);
            wood.transform.rotation = Quaternion.Euler(0, i*18f, 22f);
            var n = wood.AddComponent<DhalyaResourceNode>();
            n.resourceType = DhalyaResourceNode.ResourceType.Madeira;
            n.amount = 5;
            ResourcePickup pickup = wood.AddComponent<ResourcePickup>();
            pickup.saveId = "madeira_" + i; pickup.resource = ResourceKind.Madeira; pickup.amount = 5;
        }

        for(int i=0;i<8;i++)
        {
            Vector3 p = new Vector3(92 + (i%4)*5, .5f, -15 + (i/4)*8);
            GameObject rock = Sphere("Recurso_Pedra", p, new Vector3(1.4f,.9f,1.2f), sidewalkMat);
            var n = rock.AddComponent<DhalyaResourceNode>();
            n.resourceType = DhalyaResourceNode.ResourceType.Pedra;
            n.amount = 4;
            ResourcePickup pickup = rock.AddComponent<ResourcePickup>();
            pickup.saveId = "pedra_" + i; pickup.resource = ResourceKind.Pedra; pickup.amount = 4;
        }

        for(int i=0;i<8;i++)
        {
            Vector3 p = new Vector3(48 + (i%4)*4, .6f, -30 + (i/4)*5);
            GameObject scrap = Cube("Recurso_Sucata", p, new Vector3(1.5f,1f,1.2f), metalMat);
            scrap.transform.rotation = Quaternion.Euler(i*8f, i*29f, i*5f);
            var n = scrap.AddComponent<DhalyaResourceNode>();
            n.resourceType = DhalyaResourceNode.ResourceType.Sucata;
            n.amount = 3;
            ResourcePickup pickup = scrap.AddComponent<ResourcePickup>();
            pickup.saveId = "sucata_" + i; pickup.resource = ResourceKind.Sucata; pickup.amount = 3;
        }
    }

    static void CreateTree(Vector3 pos, Transform parent = null)
    {
        GameObject t = new GameObject("Arvore");
        t.transform.SetParent(parent ? parent : root);
        Cylinder("Tronco", pos, new Vector3(.55f,2.1f,.55f), woodMat, t.transform);
        Sphere("Copa", pos + Vector3.up*3.2f, new Vector3(2.6f,2.2f,2.6f), greenMat, t.transform);
    }

    static void CreateVegetation()
    {
        System.Random rng = new System.Random(2609);
        for(int i=0;i<55;i++)
        {
            float x = (float)(rng.NextDouble()*230 - 115);
            float z = (float)(rng.NextDouble()*230 - 115);
            if (Mathf.Abs(x) < 18f) continue;
            if (Mathf.Abs(z-58f) < 10f || Mathf.Abs(z+55f) < 10f) continue;
            CreateTree(new Vector3(x,1.9f,z));
        }

        for(int i=0;i<90;i++)
        {
            float x = (float)(rng.NextDouble()*235 - 117.5);
            float z = (float)(rng.NextDouble()*235 - 117.5);
            GameObject b = Sphere("Arbusto", new Vector3(x,.55f,z), new Vector3(1.2f,.65f,1.2f), i%3==0 ? dryGreenMat : greenMat);
            Collider c = b.GetComponent<Collider>();
            if (c) Object.DestroyImmediate(c);
        }
    }

    static void CreateStreetProps()
    {
        // Lamp posts
        for(int z=-100; z<=100; z+=25)
        {
            CreateLampPost(new Vector3(-15,0,z));
            CreateLampPost(new Vector3(15,0,z+12));
        }

        // Abandoned cars
        Vector3[] cars = {
            new Vector3(-4,.8f,34), new Vector3(4,.8f,-20), new Vector3(-4,.8f,-74),
            new Vector3(35,.8f,59), new Vector3(-75,.8f,58)
        };
        for(int i=0;i<cars.Length;i++)
        {
            GameObject car = Cube("Carro_Abandonado_"+(i+1), cars[i], new Vector3(4.3f,1.4f,2.1f), metalMat);
            car.transform.rotation = Quaternion.Euler(0, i*33f, i%2==0 ? 3f : -2f);
            Cube("Cabine", cars[i] + Vector3.up*1.1f, new Vector3(2.2f,1.2f,1.8f), blueGlowMat, car.transform);
        }
    }

    static void CreateLampPost(Vector3 pos)
    {
        GameObject p = new GameObject("Poste");
        p.transform.SetParent(root);
        Cylinder("Haste", pos + Vector3.up*3.2f, new Vector3(.15f,3.2f,.15f), metalMat, p.transform);
        Cube("Braco", pos + new Vector3(.8f,6.1f,0), new Vector3(1.6f,.12f,.12f), metalMat, p.transform);
        Cube("Luz", pos + new Vector3(1.55f,5.9f,0), new Vector3(.45f,.22f,.35f), blueGlowMat, p.transform);
    }

    static void CreateFutureTech()
    {
        Vector3[] tech = {
            new Vector3(-15,.9f,88), new Vector3(86,.9f,10), new Vector3(-88,.9f,-76)
        };
        for(int i=0;i<tech.Length;i++)
        {
            GameObject pedestal = Cylinder("Terminal_Antigo_"+(i+1), tech[i], new Vector3(.7f,.9f,.7f), metalMat);
            Cube("Painel_Holografico", tech[i] + Vector3.up*1.2f, new Vector3(1.4f,.8f,.12f), blueGlowMat, pedestal.transform);
            pedestal.AddComponent<FutureStationInteractable>().prompt = "Pressione E para examinar o terminal antigo";
        }
    }

    static void CreatePlayer()
    {
        GameObject player = GameObject.CreatePrimitive(PrimitiveType.Capsule);
        player.name = "PLAYER_PLACEHOLDER";
        player.transform.SetParent(root);
        player.transform.position = new Vector3(-35,1.1f,-88);

        Object.DestroyImmediate(player.GetComponent<CapsuleCollider>());
        CharacterController cc = player.AddComponent<CharacterController>();
        cc.height = 2f;
        cc.radius = .45f;

        player.AddComponent<SimpleThirdPersonController>();
        player.AddComponent<InteractionDetector>();

        GameObject camGO = new GameObject("Main Camera");
        Camera cam = camGO.AddComponent<Camera>();
        camGO.tag = "MainCamera";
        camGO.transform.position = player.transform.position + new Vector3(0,3,-6);
        camGO.AddComponent<AudioListener>();
    }

    static void CreateGameSystems()
    {
        GameObject systems = new GameObject("SISTEMAS_DHALYACITY");
        systems.transform.SetParent(root);
        systems.AddComponent<InventorySystem>();
        systems.AddComponent<BuildSystem>();
        systems.AddComponent<SaveSystem>();
        systems.AddComponent<GameUI>();
        WeatherSystem weather = systems.AddComponent<WeatherSystem>();
        GameObject sun = GameObject.Find("Sun");
        if (sun != null) weather.sun = sun.GetComponent<Light>();
    }
}
#endif
