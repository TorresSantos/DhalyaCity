using System.Collections.Generic;
using UnityEngine;

namespace DhalyaCity
{
    public class PlacedChest : MonoBehaviour
    {
        public ContainerInteractable container;
        void Awake() { container = GetComponent<ContainerInteractable>(); }
    }

    public class BuildSystem : MonoBehaviour
    {
        public static BuildSystem Instance { get; private set; }
        public Material validMaterial;
        public Material invalidMaterial;
        bool active;
        GameObject preview;
        readonly List<PlacedChest> chests = new List<PlacedChest>();
        public bool IsActive => active;

        void Awake() { Instance = this; }
        void Start() { CreateMaterials(); }
        void Update()
        {
            if (Input.GetKeyDown(KeyCode.B)) Toggle();
            if (!active) return;
            UpdatePreview();
            if (Input.GetMouseButtonDown(0)) TryPlace();
            if (Input.GetMouseButtonDown(1) || Input.GetKeyDown(KeyCode.Escape)) Toggle();
        }
        void CreateMaterials()
        {
            validMaterial = MakeMaterial(new Color(.16f, .85f, .8f, .45f));
            invalidMaterial = MakeMaterial(new Color(.95f, .2f, .2f, .45f));
        }
        Material MakeMaterial(Color color)
        {
            Material material = new Material(Shader.Find("Standard"));
            material.color = color; material.SetFloat("_Mode", 3); material.SetInt("_SrcBlend", (int)UnityEngine.Rendering.BlendMode.SrcAlpha); material.SetInt("_DstBlend", (int)UnityEngine.Rendering.BlendMode.OneMinusSrcAlpha); material.SetInt("_ZWrite", 0); material.renderQueue = 3000;
            return material;
        }
        public void Toggle()
        {
            active = !active;
            if (!active && preview != null) preview.SetActive(false);
            GameUI.Instance?.ShowToast(active ? "Modo construção: clique em uma área permitida para colocar um baú" : "Modo construção fechado");
        }
        bool GetPlacement(out Vector3 point, out bool valid)
        {
            point = Vector3.zero; valid = false;
            Camera camera = Camera.main;
            if (camera == null || !Physics.Raycast(camera.ScreenPointToRay(Input.mousePosition), out RaycastHit hit, 80f)) return false;
            point = hit.point;
            valid = hit.collider.GetComponent<DhalyaBuildZone>() != null || hit.collider.GetComponentInParent<DhalyaBuildZone>() != null;
            return true;
        }
        void UpdatePreview()
        {
            if (preview == null) preview = CreateChest("PREVIA_BAU", validMaterial, false);
            if (GetPlacement(out Vector3 point, out bool valid))
            {
                preview.SetActive(true); preview.transform.position = new Vector3(point.x, .8f, point.z);
                preview.GetComponent<Renderer>().sharedMaterial = valid ? validMaterial : invalidMaterial;
            }
            else preview.SetActive(false);
        }
        void TryPlace()
        {
            if (!GetPlacement(out Vector3 point, out bool valid) || !valid) { GameUI.Instance?.ShowToast("O baú só pode ser colocado na área de construção."); return; }
            if (InventorySystem.Instance.Get(ResourceKind.Madeira) < 5 || InventorySystem.Instance.Get(ResourceKind.Sucata) < 3) { GameUI.Instance?.ShowToast("Custo: 5 Madeira e 3 Sucata."); return; }
            InventorySystem.Instance.Spend(ResourceKind.Madeira, 5); InventorySystem.Instance.Spend(ResourceKind.Sucata, 3);
            CreatePlacedChest(new Vector3(point.x, .8f, point.z)); GameUI.Instance?.ShowToast("Baú construído."); Toggle();
        }
        GameObject CreateChest(string name, Material material, bool collider)
        {
            GameObject chest = GameObject.CreatePrimitive(PrimitiveType.Cube);
            chest.name = name; chest.transform.localScale = new Vector3(1.5f, 1.1f, .9f);
            if (!collider) Object.Destroy(chest.GetComponent<Collider>());
            chest.GetComponent<Renderer>().sharedMaterial = material;
            return chest;
        }
        public void CreatePlacedChest(Vector3 position)
        {
            GameObject chest = CreateChest("Bau_Armazenamento", MakeMaterial(new Color(.34f, .19f, .08f)), true);
            chest.transform.position = position;
            ContainerInteractable container = chest.AddComponent<ContainerInteractable>();
            container.prompt = "Pressione E para abrir o baú";
            chests.Add(chest.AddComponent<PlacedChest>());
        }
        public List<PlacedChest> Chests => chests;
        public void ClearChests()
        {
            foreach (PlacedChest chest in chests) if (chest != null) Destroy(chest.gameObject);
            chests.Clear();
        }
    }
}
