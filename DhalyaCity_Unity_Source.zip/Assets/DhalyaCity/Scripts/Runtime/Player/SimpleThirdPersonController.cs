using UnityEngine;

namespace DhalyaCity
{
    [RequireComponent(typeof(CharacterController))]
    public class SimpleThirdPersonController : MonoBehaviour
    {
        public float walkSpeed = 4.5f;
        public float runSpeed = 7.5f;
        public float jumpForce = 6f;
        public float gravity = -18f;
        public float mouseSensitivity = 2.2f;
        public float cameraDistance = 6f;
        public float cameraHeight = 2.2f;
        public float cameraRadius = .25f;

        CharacterController controller;
        Transform pivot;
        Camera playerCamera;
        float verticalVelocity;
        float yaw;
        float pitch = 15f;
        public float Stamina { get; private set; } = 100f;

        void Awake()
        {
            controller = GetComponent<CharacterController>();
            playerCamera = Camera.main;
            pivot = new GameObject("CameraPivot").transform;
            pivot.SetParent(transform);
            pivot.localPosition = Vector3.up * 1.55f;
            if (playerCamera != null) playerCamera.transform.SetParent(pivot);
            Cursor.lockState = CursorLockMode.Locked;
            Cursor.visible = false;
        }

        void Update()
        {
            yaw += Input.GetAxis("Mouse X") * mouseSensitivity;
            pitch = Mathf.Clamp(pitch - Input.GetAxis("Mouse Y") * mouseSensitivity, -20f, 60f);
            transform.rotation = Quaternion.Euler(0f, yaw, 0f);

            float h = Input.GetAxisRaw("Horizontal");
            float v = Input.GetAxisRaw("Vertical");
            bool running = Input.GetKey(KeyCode.LeftShift) && Stamina > 0f && new Vector2(h, v).sqrMagnitude > .01f;
            float speed = running ? runSpeed : walkSpeed;
            Stamina = Mathf.Clamp(Stamina + (running ? -18f : 11f) * Time.deltaTime, 0f, 100f);

            if (controller.isGrounded)
            {
                if (verticalVelocity < 0f) verticalVelocity = -2f;
                if (Input.GetButtonDown("Jump")) verticalVelocity = jumpForce;
            }
            verticalVelocity += gravity * Time.deltaTime;
            Vector3 movement = (transform.right * h + transform.forward * v).normalized * speed;
            controller.Move((movement + Vector3.up * verticalVelocity) * Time.deltaTime);
            UpdateCamera();
        }

        void UpdateCamera()
        {
            if (playerCamera == null) return;
            pivot.rotation = Quaternion.Euler(pitch, yaw, 0f);
            Vector3 desired = pivot.position - pivot.forward * cameraDistance + Vector3.up * cameraHeight;
            Vector3 direction = desired - pivot.position;
            float distance = direction.magnitude;
            if (Physics.SphereCast(pivot.position, cameraRadius, direction.normalized, out RaycastHit hit, distance, ~0, QueryTriggerInteraction.Ignore))
                desired = pivot.position + direction.normalized * Mathf.Max(.35f, hit.distance - cameraRadius);
            playerCamera.transform.position = Vector3.Lerp(playerCamera.transform.position, desired, 16f * Time.deltaTime);
            playerCamera.transform.rotation = Quaternion.LookRotation(pivot.position + Vector3.up * .35f - playerCamera.transform.position);
        }
    }

    public class DhalyaResourceNode : MonoBehaviour
    {
        public enum ResourceType { Madeira, Pedra, Sucata }
        public ResourceType resourceType;
        public int amount = 5;
    }

    public class DhalyaBuildZone : MonoBehaviour { public string zoneName = "Zona de Construção"; }
    public class DhalyaFutureExpansion : MonoBehaviour { public string futureUse; }
}
