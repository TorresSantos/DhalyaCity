using System;
using UnityEngine;

namespace DhalyaCity
{
    public enum ResourceKind { Madeira, Sucata, Pedra }

    public class InventorySystem : MonoBehaviour
    {
        public static InventorySystem Instance { get; private set; }
        public int Wood { get; private set; }
        public int Scrap { get; private set; }
        public int Stone { get; private set; }
        public event Action Changed;

        void Awake() { Instance = this; }
        public int Get(ResourceKind kind) => kind == ResourceKind.Madeira ? Wood : kind == ResourceKind.Sucata ? Scrap : Stone;
        public void Add(ResourceKind kind, int amount)
        {
            if (kind == ResourceKind.Madeira) Wood += amount;
            else if (kind == ResourceKind.Sucata) Scrap += amount;
            else Stone += amount;
            Changed?.Invoke();
        }
        public bool Spend(ResourceKind kind, int amount)
        {
            if (Get(kind) < amount) return false;
            Add(kind, -amount);
            return true;
        }
        public void SetAmounts(int wood, int scrap, int stone)
        {
            Wood = Mathf.Max(0, wood); Scrap = Mathf.Max(0, scrap); Stone = Mathf.Max(0, stone); Changed?.Invoke();
        }
    }
}
