using UnityEngine;

namespace DhalyaCity
{
    public abstract class Interactable : MonoBehaviour
    {
        [TextArea] public string prompt = "Pressione E para interagir";
        public virtual string Prompt => prompt;
        public abstract void Interact();
    }

    public class InteractionDetector : MonoBehaviour
    {
        public float range = 3.2f;
        Interactable current;
        void Update()
        {
            current = null;
            Camera cam = Camera.main;
            if (cam != null && Physics.Raycast(cam.transform.position, cam.transform.forward, out RaycastHit hit, range, ~0, QueryTriggerInteraction.Collide))
                current = hit.collider.GetComponentInParent<Interactable>();
            GameUI.Instance?.SetInteraction(current == null ? string.Empty : current.Prompt);
            if (current != null && Input.GetKeyDown(KeyCode.E)) current.Interact();
        }
    }

    public class DoorInteractable : Interactable
    {
        public string saveId;
        public float openAngle = 100f;
        bool open;
        Quaternion closedRotation;
        void Awake() { closedRotation = transform.localRotation; prompt = "Pressione E para abrir a porta"; }
        public override void Interact() { SetOpen(!open); }
        public void SetOpen(bool value)
        {
            open = value;
            transform.localRotation = closedRotation * Quaternion.Euler(0f, open ? openAngle : 0f, 0f);
            prompt = open ? "Pressione E para fechar a porta" : "Pressione E para abrir a porta";
        }
        public bool IsOpen => open;
    }

    public class ResourcePickup : Interactable
    {
        public string saveId;
        public ResourceKind resource;
        public int amount = 5;
        void Awake() { prompt = "Pressione E para coletar " + resource; }
        public override void Interact()
        {
            InventorySystem.Instance.Add(resource, amount);
            SaveSystem.Instance?.MarkCollected(saveId);
            GameUI.Instance?.ShowToast("+" + amount + " " + resource);
            gameObject.SetActive(false);
        }
    }

    public class ContainerInteractable : Interactable
    {
        public int wood;
        public int scrap;
        public int stone;
        public override void Interact() { GameUI.Instance?.ToggleContainer(this); }
        public void Deposit(ResourceKind kind)
        {
            if (InventorySystem.Instance.Spend(kind, 1))
            {
                if (kind == ResourceKind.Madeira) wood++;
                else if (kind == ResourceKind.Sucata) scrap++;
                else stone++;
            }
        }
    }

    public class FutureStationInteractable : Interactable
    {
        public string message = "Esta estação será restaurada mais tarde.";
        public override void Interact() { GameUI.Instance?.ShowToast(message); }
    }
}
