using UnityEngine;

namespace DhalyaCity
{
    public class GameUI : MonoBehaviour
    {
        public static GameUI Instance { get; private set; }
        string interaction;
        string toast;
        float toastUntil;
        ContainerInteractable openContainer;
        GUIStyle title, label, hint, toastStyle;
        void Awake() { Instance = this; }
        public void SetInteraction(string value) { interaction = value; }
        public void ShowToast(string value) { toast = value; toastUntil = Time.time + 2.4f; }
        public void ToggleContainer(ContainerInteractable container)
        {
            openContainer = openContainer == container ? null : container;
            Cursor.lockState = openContainer == null ? CursorLockMode.Locked : CursorLockMode.None;
            Cursor.visible = openContainer != null;
        }
        void Styles()
        {
            if (title != null) return;
            title = new GUIStyle(GUI.skin.label) { fontSize = 20, fontStyle = FontStyle.Bold, normal = { textColor = new Color(.36f, .95f, .92f) } };
            label = new GUIStyle(GUI.skin.label) { fontSize = 15, normal = { textColor = Color.white } };
            hint = new GUIStyle(GUI.skin.label) { fontSize = 16, alignment = TextAnchor.MiddleCenter, normal = { textColor = Color.white } };
            toastStyle = new GUIStyle(hint) { fontSize = 18, fontStyle = FontStyle.Bold };
        }
        void OnGUI()
        {
            Styles();
            GUI.Box(new Rect(16, 16, 220, 146), ""); GUI.Label(new Rect(30, 26, 190, 28), "DHALYACITY  |  CODO", title);
            SimpleThirdPersonController player = FindFirstObjectByType<SimpleThirdPersonController>();
            GUI.Label(new Rect(30, 62, 180, 22), "Vida       100", label);
            GUI.Label(new Rect(30, 84, 180, 22), "Energia   " + Mathf.RoundToInt(player == null ? 100 : player.Stamina), label);
            InventorySystem inventory = InventorySystem.Instance;
            if (inventory != null)
            {
                GUI.Label(new Rect(30, 110, 180, 22), "Madeira  " + inventory.Wood + "   Sucata  " + inventory.Scrap, label);
                GUI.Label(new Rect(30, 132, 180, 22), "Pedra      " + inventory.Stone, label);
            }
            GUI.Label(new Rect(16, Screen.height - 35, 600, 22), "B: construir baú  |  F5: salvar  |  F9: carregar", label);
            if (!string.IsNullOrEmpty(interaction)) GUI.Label(new Rect(Screen.width / 2 - 190, Screen.height - 85, 380, 28), interaction, hint);
            if (Time.time < toastUntil) GUI.Label(new Rect(Screen.width / 2 - 210, 35, 420, 32), toast, toastStyle);
            if (BuildSystem.Instance != null && BuildSystem.Instance.IsActive) GUI.Label(new Rect(Screen.width / 2 - 220, 75, 440, 25), "BAÚ: 5 madeira + 3 sucata", toastStyle);
            if (openContainer != null) DrawContainer();
        }
        void DrawContainer()
        {
            Rect box = new Rect(Screen.width / 2 - 180, Screen.height / 2 - 140, 360, 280);
            GUI.Box(box, "Baú de armazenamento");
            GUI.Label(new Rect(box.x + 25, box.y + 45, 300, 25), "Guardado: " + openContainer.wood + " Madeira | " + openContainer.scrap + " Sucata | " + openContainer.stone + " Pedra", label);
            GUI.Label(new Rect(box.x + 25, box.y + 75, 300, 22), "Deposite uma unidade por vez:", label);
            if (GUI.Button(new Rect(box.x + 25, box.y + 110, 145, 34), "+ Madeira")) openContainer.Deposit(ResourceKind.Madeira);
            if (GUI.Button(new Rect(box.x + 190, box.y + 110, 145, 34), "+ Sucata")) openContainer.Deposit(ResourceKind.Sucata);
            if (GUI.Button(new Rect(box.x + 25, box.y + 155, 145, 34), "+ Pedra")) openContainer.Deposit(ResourceKind.Pedra);
            if (GUI.Button(new Rect(box.x + 190, box.y + 155, 145, 34), "Fechar")) ToggleContainer(openContainer);
        }
    }
}
