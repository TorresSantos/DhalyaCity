using System;
using System.Collections.Generic;
using System.IO;
using UnityEngine;

namespace DhalyaCity
{
    [Serializable] class ChestData { public Vector3 position; public int wood, scrap, stone; }
    [Serializable] class DoorData { public string id; public bool open; }
    [Serializable] class SaveData { public Vector3 playerPosition; public int wood, scrap, stone; public List<string> collected = new List<string>(); public List<DoorData> doors = new List<DoorData>(); public List<ChestData> chests = new List<ChestData>(); }
    public class SaveSystem : MonoBehaviour
    {
        public static SaveSystem Instance { get; private set; }
        readonly HashSet<string> collected = new HashSet<string>();
        string SavePath => Path.Combine(Application.persistentDataPath, "dhalyacity_slot_1.json");
        void Awake() { Instance = this; }
        void Update() { if (Input.GetKeyDown(KeyCode.F5)) SaveGame(); if (Input.GetKeyDown(KeyCode.F9)) LoadGame(); }
        public void MarkCollected(string id) { if (!string.IsNullOrEmpty(id)) collected.Add(id); }
        public void SaveGame()
        {
            SaveData data = new SaveData();
            SimpleThirdPersonController player = FindFirstObjectByType<SimpleThirdPersonController>();
            if (player != null) data.playerPosition = player.transform.position;
            InventorySystem inventory = InventorySystem.Instance;
            data.wood = inventory.Wood; data.scrap = inventory.Scrap; data.stone = inventory.Stone;
            data.collected.AddRange(collected);
            foreach (DoorInteractable door in FindObjectsByType<DoorInteractable>(FindObjectsSortMode.None)) data.doors.Add(new DoorData { id = door.saveId, open = door.IsOpen });
            foreach (PlacedChest chest in BuildSystem.Instance.Chests) if (chest != null) data.chests.Add(new ChestData { position = chest.transform.position, wood = chest.container.wood, scrap = chest.container.scrap, stone = chest.container.stone });
            File.WriteAllText(SavePath, JsonUtility.ToJson(data, true)); GameUI.Instance?.ShowToast("Jogo salvo no slot 1.");
        }
        public void LoadGame()
        {
            if (!File.Exists(SavePath)) { GameUI.Instance?.ShowToast("Ainda não existe um salvamento no slot 1."); return; }
            SaveData data = JsonUtility.FromJson<SaveData>(File.ReadAllText(SavePath));
            InventorySystem.Instance.SetAmounts(data.wood, data.scrap, data.stone); collected.Clear(); foreach (string id in data.collected) collected.Add(id);
            foreach (ResourcePickup pickup in FindObjectsByType<ResourcePickup>(FindObjectsInactive.Include, FindObjectsSortMode.None)) pickup.gameObject.SetActive(!collected.Contains(pickup.saveId));
            foreach (DoorInteractable door in FindObjectsByType<DoorInteractable>(FindObjectsSortMode.None)) { DoorData saved = data.doors.Find(x => x.id == door.saveId); if (saved != null) door.SetOpen(saved.open); }
            BuildSystem.Instance.ClearChests(); foreach (ChestData chestData in data.chests) { BuildSystem.Instance.CreatePlacedChest(chestData.position); PlacedChest chest = BuildSystem.Instance.Chests[BuildSystem.Instance.Chests.Count - 1]; chest.container.wood = chestData.wood; chest.container.scrap = chestData.scrap; chest.container.stone = chestData.stone; }
            SimpleThirdPersonController player = FindFirstObjectByType<SimpleThirdPersonController>(); if (player != null) player.transform.position = data.playerPosition;
            GameUI.Instance?.ShowToast("Salvamento carregado.");
        }
    }
}
