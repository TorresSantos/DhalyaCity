using UnityEngine;

namespace DhalyaCity
{
    public enum WeatherType { Sunny, Rain, Storm, Fog }
    public class WeatherSystem : MonoBehaviour
    {
        public WeatherType currentWeather = WeatherType.Sunny;
        public Light sun;
        void Start() { ApplyWeather(currentWeather); }
        public void ApplyWeather(WeatherType weather)
        {
            currentWeather = weather;
            if (sun != null) sun.intensity = weather == WeatherType.Sunny ? 1.15f : .55f;
            RenderSettings.ambientLight = weather == WeatherType.Sunny ? new Color(.42f, .45f, .48f) : new Color(.25f, .28f, .32f);
        }
    }
}
